# Statistics

# Revision

- [ ]  Mixed exercise 1 - **Questions 1 + 9**
- [ ]  Mixed exercise 2
- [ ]  Mixed exercise 3
- [ ]  Mixed exercise 4
- [ ]  Mixed exercise 5
- [ ]  Mixed exercise 6
- [ ]  Mixed exercise 7
- [ ]  Review exercise 1

[Data (1)](Statistics%20bfeca7eb67e7458fb38ecbebcccae131/Data%20(1)%200e3244fd102b4c7fa96650ab2b6cb83e.md)

[Measures (2)](Statistics%20bfeca7eb67e7458fb38ecbebcccae131/Measures%20(2)%2059854ccad0cd4c9bb5395fbfeca2b1f0.md)

[Representing Data (3/4)](Statistics%20bfeca7eb67e7458fb38ecbebcccae131/Representing%20Data%20(3%204)%2063414c53751344548584e3f9bcc11b07.md)

[Hypothesis Testing](Statistics%20bfeca7eb67e7458fb38ecbebcccae131/Hypothesis%20Testing%20fca5792aee2d4d3ba9dab90056a1b037.md)

[Correlation (AS4+A1)](Statistics%20bfeca7eb67e7458fb38ecbebcccae131/Correlation%20(AS4+A1)%20bc6afe45161a4f5588d6abe134fe8b85.md)

[Probability (AS5+A2)](Statistics%20bfeca7eb67e7458fb38ecbebcccae131/Probability%20(AS5+A2)%204bf90aacbd2b44aab64fd7f075354422.md)

[Distributions (AS6+A3)](Statistics%20bfeca7eb67e7458fb38ecbebcccae131/Distributions%20(AS6+A3)%20bef75c6c1a454b6eb9210286b9bba84e.md)