# Pure Yr1

Pure Maths is the fundamental concepts Maths is built upon.

# Revision Notes

- Almost completed review exercise 1 (History book)
- Almost completed review exercise 2 (History book)
- Has not completed review exercise 3
- **Revise alternate/whatever angles!**

[1. Algebra](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/1%20Algebra%20f10f332141ae4757a62d727307a855cf.md)

[2. Quadratics](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/2%20Quadratics%20fc583a3aa5bc4f79aa49bec9edbd696c.md)

[3. S.E. + Inequalities](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/3%20S%20E%20+%20Inequalities%20ab8cfd63313a400e9a722633eb906679.md)

[4. Transforms](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/4%20Transforms%2059c3724fbb3b4a7983ac8e5f9f3e7752.md)

[5. Line Graphs](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/5%20Line%20Graphs%201bb39694e8044fd7ad983da772329326.md)

[6. Circles](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/6%20Circles%208c125b56567b43129edc73713a2c06d9.md)

[7. Algebraic](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/7%20Algebraic%202b5c9ac452f7462da0cc3ec3c1e1c0b2.md)

[8. Binomials](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/8%20Binomials%2027058643468d4a70aed8626a1d98cb48.md)

[9. Trig Ratios](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/9%20Trig%20Ratios%20cf284eb47c5948afb98955a25789c93d.md)

[10. Trig Equations](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/10%20Trig%20Equations%2016b133024c9443859a7194d8141f538e.md)

[11. Vectors](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/11%20Vectors%20bdf70597e6784ffda0f9f8b63bf083e6.md)

[12. Differentiation](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/12%20Differentiation%20c85e6b7e84f34b4e91d0eb6931f5133a.md)

[13. Integration](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/13%20Integration%20ffe92242fd9449488521bd01c1877adc.md)

[14. Exp/Logs](Pure%20Yr1%20d643d48607f045cebabc1133c0cb9f9c/14%20Exp%20Logs%201e786def7dce44f6a1b02aa4bcae6dd5.md)